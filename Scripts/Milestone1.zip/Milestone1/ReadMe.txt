Instructions - WASD to move, F to toggle between past and future, Esc to exit game

List of Bugs - 
1. Camera clips through walls
2. If player changes time, objects can spawn onto player.
3. Shadows in future look pixely

Team Member Contribution:
Adam Liebowich - Level design and lighting
Amberly Brewster - Story/Documetation
Christain Orellana - Time Toggle/Player Controller
Colin Hayes - Setting up Unity Collab
Christain Espinoza - Absent
Dante McCain - Art
Dominic Lincourt - Player Controller/Camera Controller
Jeffrey Fox - Story/ Documentation
